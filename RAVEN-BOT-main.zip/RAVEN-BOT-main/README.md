# 𝗥𝗔𝗩𝗘𝗡-𝗕𝗢𝗧
<div align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=HOLLA+THIS+IS+RAVEN-BOT;MULTI+DEVICE+WHATSAPP+BOT;MADE+TO+HELP+WHATSAPP+USERS;STAR+AND+FORK+THE+REPO" alt="Typing SVG" />
  </a>
</p>
  
<p align="center">

[![Nick Hunter](https://github.com/HunterNick2.png?lenght=50width=50)](https://github.com/HunterNick2)
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=RAVEN+WHATSAPP+BOT" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-𝗡𝗶𝗰𝗸_𝗛𝘂𝗻𝘁𝗲𝗿-blue.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/HunterNick2?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/HunterNick2?label=Followers&style=social"></a>
<a href="https://github.com/HunterNick2/RAVEN-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/HunterNick2/RAVEN-BOT?&style=social"></a>
<a href="https://github.com/HunterNick2/RAVEN-BOT/network/members"><img title="Fork" src="https://img.shields.io/github/forks/HunterNick2/RAVEN-BOT?style=social"></a>
<a href="https://github.com/HunterNick2/RAVEN-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/HunterNick2/RAVEN-BOT?label=Watching&style=social"></a>
</p>
 

## ` Contact me`

<p align="center">

<a href="https://api.whatsapp.com/send?phone=254114660061&text=Hello+Raven+dev+i+need+your+Help+on..."><img src="https://img.shields.io/badge/Contact-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


***This bot is created with the help of NodeJS and uses [Baileys](https://github.com/whiskeysockets/Baileys)***


## DISCLAIMER
- Modifying the bot structure is at your own risk. We won't offer technical support in case of errors resulting.

- Do not delete the credits given,  you can add yourself instead.

## FEATURES
This is a highly customisable simple whatsapp bot with group management features and few media commands and chatgpt courtesy of Openai.

Our AI features use random APIs to run, so sometimes they may be down.

 SET-UP

## ` Fork this repo`
<p align="centre">
<a href="https://github.com/HunterNick2/RAVEN-BOT/fork"><img src="https://img.shields.io/badge/Fork%20Create-purple?style=for-the-badge&logo=github" alt="FORK RAVEN-BOT" width="160"></a>
<p/>

  
## ` Pair onrender`
<p align="centre">
<a href="https://pairing-raven.onrender.com"><img height= "37" title="Author" src="https://img.shields.io/badge/Session-green?style=for-the-badge&logo=render"></a>
<p/>
            

###  ` Deploy to Heroku`
<p align="center">
     <a href="https://verify-me-umber.vercel.app/">
       <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku"/>
     </a>
 </p>
 

    

- Fill in the required variables into your hosting site for bot to work.
 </h2>
     

    
 





## License

[MIT License](https://github.com/HunterNick2/RAVEN-BOT/blob/main/LICENSE)

Copyright (c) 2025 RAVEN-BOT 

